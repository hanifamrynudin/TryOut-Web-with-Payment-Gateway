<?php 
$lang['duplicate_question_found'] = "Similar existing questions "; 

