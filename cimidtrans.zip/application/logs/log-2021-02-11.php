<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-11 04:28:38 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-11 04:35:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-11 04:38:23 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\cimidtrans\application\models\Quiz_model.php 155
ERROR - 2021-02-11 04:38:34 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\cimidtrans\application\models\Quiz_model.php 193
ERROR - 2021-02-11 04:45:17 --> Severity: error --> Exception: syntax error, unexpected '');?>" class="btn btn-success"' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:45:25 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:45:26 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:45:26 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:45:29 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:45:52 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:46:25 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:46:26 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group.php 51
ERROR - 2021-02-11 04:47:16 --> Severity: error --> Exception: Too few arguments to function Quiz::quiz_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\Quiz.php 452
ERROR - 2021-02-11 04:47:20 --> Severity: error --> Exception: Too few arguments to function Quiz::quiz_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\Quiz.php 452
ERROR - 2021-02-11 04:47:32 --> Severity: error --> Exception: Too few arguments to function Quiz::quiz_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\Quiz.php 452
ERROR - 2021-02-11 04:53:09 --> Severity: error --> Exception: Call to a member function get_quiz() on null C:\xampp\htdocs\cimidtrans\application\controllers\User.php 318
ERROR - 2021-02-11 04:58:19 --> Severity: error --> Exception: syntax error, unexpected 'gid' (T_STRING), expecting ')' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 320
ERROR - 2021-02-11 05:01:56 --> Severity: error --> Exception: Call to a member function get_quiz() on null C:\xampp\htdocs\cimidtrans\application\controllers\User.php 355
ERROR - 2021-02-11 05:02:12 --> Severity: error --> Exception: Too few arguments to function User::change_group_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 338
ERROR - 2021-02-11 05:02:39 --> Severity: error --> Exception: Too few arguments to function User::change_group_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 338
ERROR - 2021-02-11 05:03:33 --> Severity: error --> Exception: Too few arguments to function User::change_group_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 338
ERROR - 2021-02-11 05:03:36 --> Severity: error --> Exception: Too few arguments to function User::change_group_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 338
ERROR - 2021-02-11 05:04:23 --> Severity: error --> Exception: Too few arguments to function User::quiz_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 338
ERROR - 2021-02-11 05:04:34 --> Severity: error --> Exception: Too few arguments to function Quiz::quiz_detail(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\Quiz.php 452
ERROR - 2021-02-11 05:05:21 --> Severity: error --> Exception: Call to a member function get_quiz() on null C:\xampp\htdocs\cimidtrans\application\controllers\User.php 355
ERROR - 2021-02-11 05:05:24 --> Severity: error --> Exception: Call to a member function get_quiz() on null C:\xampp\htdocs\cimidtrans\application\controllers\User.php 355
ERROR - 2021-02-11 05:05:57 --> Severity: error --> Exception: Call to a member function get_quiz() on null C:\xampp\htdocs\cimidtrans\application\controllers\User.php 341
ERROR - 2021-02-11 05:12:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 31
ERROR - 2021-02-11 05:12:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 31
ERROR - 2021-02-11 05:12:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 31
ERROR - 2021-02-11 05:12:13 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 31
ERROR - 2021-02-11 05:12:23 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 31
ERROR - 2021-02-11 05:12:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 27
ERROR - 2021-02-11 05:13:28 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:13:29 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:13:32 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 49
ERROR - 2021-02-11 05:13:35 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 49
ERROR - 2021-02-11 05:13:37 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 49
ERROR - 2021-02-11 05:14:54 --> Could not find the language line "Email"
ERROR - 2021-02-11 05:16:08 --> Could not find the language line "name_group"
ERROR - 2021-02-11 05:16:09 --> Could not find the language line "name_group"
ERROR - 2021-02-11 05:16:25 --> Could not find the language line "group"
ERROR - 2021-02-11 05:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\view_studymaterial.php 62
ERROR - 2021-02-11 05:33:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 27
ERROR - 2021-02-11 05:38:24 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 95
ERROR - 2021-02-11 05:38:38 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 95
ERROR - 2021-02-11 05:43:13 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 106
ERROR - 2021-02-11 05:43:29 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 101
ERROR - 2021-02-11 05:43:29 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 101
ERROR - 2021-02-11 05:43:30 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 101
ERROR - 2021-02-11 05:43:32 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 101
ERROR - 2021-02-11 05:44:06 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 05:44:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:44:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 50
ERROR - 2021-02-11 05:45:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 36
ERROR - 2021-02-11 05:45:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 36
ERROR - 2021-02-11 05:45:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 36
ERROR - 2021-02-11 05:45:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 36
ERROR - 2021-02-11 05:45:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 36
ERROR - 2021-02-11 05:45:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 69
ERROR - 2021-02-11 05:46:41 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 65
ERROR - 2021-02-11 05:46:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:46:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:46:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:46:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:46:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:25 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 38
ERROR - 2021-02-11 05:47:36 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:47:37 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 40
ERROR - 2021-02-11 05:48:17 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 64
ERROR - 2021-02-11 05:49:46 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 73
ERROR - 2021-02-11 05:49:46 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 73
ERROR - 2021-02-11 05:49:59 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 73
ERROR - 2021-02-11 05:50:03 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 73
ERROR - 2021-02-11 05:50:04 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 73
ERROR - 2021-02-11 05:58:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 30
ERROR - 2021-02-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 30
ERROR - 2021-02-11 05:58:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 30
ERROR - 2021-02-11 05:58:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 30
ERROR - 2021-02-11 06:20:01 --> Could not find the language line ""
ERROR - 2021-02-11 06:20:45 --> Could not find the language line ""
ERROR - 2021-02-11 06:20:56 --> Could not find the language line ""
ERROR - 2021-02-11 06:22:46 --> Could not find the language line ""
ERROR - 2021-02-11 06:22:47 --> Could not find the language line ""
ERROR - 2021-02-11 06:23:09 --> Could not find the language line ""
ERROR - 2021-02-11 06:24:50 --> Could not find the language line ""
ERROR - 2021-02-11 06:25:00 --> Could not find the language line ""
ERROR - 2021-02-11 06:26:05 --> Could not find the language line ""
ERROR - 2021-02-11 06:34:33 --> Could not find the language line ""
ERROR - 2021-02-11 06:34:40 --> Could not find the language line ""
ERROR - 2021-02-11 06:34:52 --> Could not find the language line ""
ERROR - 2021-02-11 06:34:55 --> Could not find the language line ""
ERROR - 2021-02-11 06:35:06 --> Could not find the language line ""
ERROR - 2021-02-11 06:35:24 --> Could not find the language line ""
ERROR - 2021-02-11 06:35:24 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:13 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:26 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:47 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:48 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:48 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:57 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:36:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:37:28 --> Could not find the language line ""
ERROR - 2021-02-11 06:37:41 --> Could not find the language line ""
ERROR - 2021-02-11 06:38:03 --> Could not find the language line ""
ERROR - 2021-02-11 06:38:30 --> Could not find the language line ""
ERROR - 2021-02-11 06:38:31 --> Could not find the language line ""
ERROR - 2021-02-11 06:38:53 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:06 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:19 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:32 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:46 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:51 --> Could not find the language line ""
ERROR - 2021-02-11 06:39:57 --> Could not find the language line ""
ERROR - 2021-02-11 06:41:20 --> Could not find the language line ""
ERROR - 2021-02-11 06:42:49 --> Could not find the language line ""
ERROR - 2021-02-11 06:42:49 --> Could not find the language line ""
ERROR - 2021-02-11 06:42:50 --> Could not find the language line ""
ERROR - 2021-02-11 06:43:29 --> Could not find the language line ""
ERROR - 2021-02-11 06:43:33 --> Could not find the language line ""
ERROR - 2021-02-11 06:45:19 --> Could not find the language line ""
ERROR - 2021-02-11 06:45:50 --> Could not find the language line ""
ERROR - 2021-02-11 06:45:56 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:30 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:34 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:41 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:44 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:46 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:46 --> Could not find the language line ""
ERROR - 2021-02-11 06:47:48 --> Could not find the language line ""
ERROR - 2021-02-11 06:48:54 --> Could not find the language line ""
ERROR - 2021-02-11 06:49:01 --> Could not find the language line ""
ERROR - 2021-02-11 06:49:03 --> Could not find the language line ""
ERROR - 2021-02-11 06:49:05 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:20 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:36 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:36 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:37 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:37 --> Could not find the language line ""
ERROR - 2021-02-11 06:51:38 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:20 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:21 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:26 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:26 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:27 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:41 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:42 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:43 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:43 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:43 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:53 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:58 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:52:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:53:31 --> Could not find the language line ""
ERROR - 2021-02-11 06:53:31 --> Could not find the language line ""
ERROR - 2021-02-11 06:53:32 --> Could not find the language line ""
ERROR - 2021-02-11 06:53:32 --> Could not find the language line ""
ERROR - 2021-02-11 06:53:32 --> Could not find the language line ""
ERROR - 2021-02-11 06:55:30 --> Could not find the language line ""
ERROR - 2021-02-11 06:55:31 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:54 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:55 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:56 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:56 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:56 --> Could not find the language line ""
ERROR - 2021-02-11 06:56:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:57:11 --> Could not find the language line ""
ERROR - 2021-02-11 06:57:23 --> Could not find the language line ""
ERROR - 2021-02-11 06:57:24 --> Could not find the language line ""
ERROR - 2021-02-11 06:57:54 --> Could not find the language line ""
ERROR - 2021-02-11 06:57:59 --> Could not find the language line ""
ERROR - 2021-02-11 06:58:06 --> Could not find the language line ""
ERROR - 2021-02-11 06:58:08 --> Could not find the language line ""
ERROR - 2021-02-11 06:58:10 --> Could not find the language line ""
ERROR - 2021-02-11 06:59:56 --> Could not find the language line ""
ERROR - 2021-02-11 07:08:18 --> Could not find the language line ""
ERROR - 2021-02-11 07:08:19 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:08:24 --> Could not find the language line ""
ERROR - 2021-02-11 07:08:25 --> Could not find the language line ""
ERROR - 2021-02-11 07:08:26 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:08:52 --> Could not find the language line ""
ERROR - 2021-02-11 07:08:54 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:09:05 --> Could not find the language line ""
ERROR - 2021-02-11 07:09:08 --> Could not find the language line ""
ERROR - 2021-02-11 07:09:09 --> Could not find the language line ""
ERROR - 2021-02-11 07:09:10 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:09:55 --> Could not find the language line ""
ERROR - 2021-02-11 07:09:58 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:10:30 --> Could not find the language line ""
ERROR - 2021-02-11 07:10:37 --> Could not find the language line ""
ERROR - 2021-02-11 07:11:01 --> Could not find the language line ""
ERROR - 2021-02-11 07:11:13 --> Could not find the language line ""
ERROR - 2021-02-11 07:11:14 --> Severity: error --> Exception: syntax error, unexpected '$kelas' (T_VARIABLE) C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 42
ERROR - 2021-02-11 07:11:52 --> Could not find the language line ""
ERROR - 2021-02-11 07:12:05 --> Could not find the language line ""
ERROR - 2021-02-11 07:13:26 --> Could not find the language line ""
ERROR - 2021-02-11 07:14:39 --> Could not find the language line ""
ERROR - 2021-02-11 07:15:09 --> Could not find the language line ""
ERROR - 2021-02-11 08:04:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-11 08:08:30 --> Could not find the language line ""
ERROR - 2021-02-11 08:16:08 --> Could not find the language line ""
ERROR - 2021-02-11 08:22:20 --> Could not find the language line ""
ERROR - 2021-02-11 08:22:21 --> Could not find the language line ""
ERROR - 2021-02-11 08:24:21 --> Could not find the language line ""
ERROR - 2021-02-11 08:24:40 --> Could not find the language line ""
ERROR - 2021-02-11 08:28:34 --> Could not find the language line ""
ERROR - 2021-02-11 08:29:03 --> Could not find the language line ""
ERROR - 2021-02-11 08:29:25 --> Could not find the language line ""
ERROR - 2021-02-11 08:29:37 --> Could not find the language line ""
ERROR - 2021-02-11 08:30:14 --> Could not find the language line ""
ERROR - 2021-02-11 08:44:49 --> Could not find the language line ""
ERROR - 2021-02-11 08:46:42 --> Could not find the language line ""
ERROR - 2021-02-11 08:49:13 --> Could not find the language line ""
ERROR - 2021-02-11 08:51:17 --> Could not find the language line ""
ERROR - 2021-02-11 08:54:51 --> Could not find the language line ""
ERROR - 2021-02-11 08:55:30 --> Could not find the language line ""
ERROR - 2021-02-11 09:06:03 --> Could not find the language line ""
ERROR - 2021-02-11 09:42:48 --> Could not find the language line ""
ERROR - 2021-02-11 09:42:49 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:42:56 --> Could not find the language line ""
ERROR - 2021-02-11 09:42:58 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:43:09 --> Could not find the language line ""
ERROR - 2021-02-11 09:43:10 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:43:32 --> Could not find the language line ""
ERROR - 2021-02-11 09:43:33 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:44:18 --> Could not find the language line ""
ERROR - 2021-02-11 09:44:19 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:44:35 --> Could not find the language line ""
ERROR - 2021-02-11 09:45:27 --> Could not find the language line ""
ERROR - 2021-02-11 09:45:28 --> Severity: error --> Exception: syntax error, unexpected ''gross_amount'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:45:31 --> Could not find the language line ""
ERROR - 2021-02-11 09:45:45 --> Could not find the language line ""
ERROR - 2021-02-11 09:45:46 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:45:58 --> Could not find the language line ""
ERROR - 2021-02-11 09:46:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:46:01 --> Could not find the language line ""
ERROR - 2021-02-11 09:46:02 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:46:26 --> Could not find the language line ""
ERROR - 2021-02-11 09:46:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:47:59 --> Could not find the language line ""
ERROR - 2021-02-11 09:48:00 --> Could not find the language line ""
ERROR - 2021-02-11 09:48:01 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:48:18 --> Could not find the language line ""
ERROR - 2021-02-11 09:49:38 --> Could not find the language line ""
ERROR - 2021-02-11 09:51:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 131
ERROR - 2021-02-11 09:52:18 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:52:27 --> Could not find the language line ""
ERROR - 2021-02-11 09:52:28 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:53:49 --> Could not find the language line ""
ERROR - 2021-02-11 09:53:52 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:53:59 --> Could not find the language line ""
ERROR - 2021-02-11 09:54:13 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:54:25 --> Could not find the language line ""
ERROR - 2021-02-11 09:54:27 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:54:32 --> Could not find the language line ""
ERROR - 2021-02-11 09:54:35 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:54:43 --> Could not find the language line ""
ERROR - 2021-02-11 09:54:45 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 09:55:37 --> Could not find the language line ""
ERROR - 2021-02-11 09:55:42 --> Could not find the language line ""
ERROR - 2021-02-11 09:55:47 --> Could not find the language line ""
ERROR - 2021-02-11 09:55:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:00:41 --> Could not find the language line ""
ERROR - 2021-02-11 11:00:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:01:00 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:21 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:23 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:01:28 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:33 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:39 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:43 --> Could not find the language line ""
ERROR - 2021-02-11 11:01:44 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:02:19 --> Could not find the language line ""
ERROR - 2021-02-11 11:02:21 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:02:28 --> Could not find the language line ""
ERROR - 2021-02-11 11:03:44 --> Could not find the language line ""
ERROR - 2021-02-11 11:03:53 --> Could not find the language line ""
ERROR - 2021-02-11 11:03:55 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:33:34 --> Could not find the language line ""
ERROR - 2021-02-11 11:33:35 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 140
ERROR - 2021-02-11 11:33:50 --> Could not find the language line ""
ERROR - 2021-02-11 11:34:00 --> Could not find the language line ""
ERROR - 2021-02-11 11:47:30 --> Could not find the language line ""
ERROR - 2021-02-11 12:12:58 --> Could not find the language line ""
ERROR - 2021-02-11 12:13:09 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 138
ERROR - 2021-02-11 12:13:46 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 138
ERROR - 2021-02-11 12:14:10 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`) VALUES ('1863910750', '100.00', 'bank_transfer', '2021-02-11 13:43:09', NULL, NULL)
ERROR - 2021-02-11 12:14:30 --> Could not find the language line ""
ERROR - 2021-02-11 12:14:38 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`) VALUES ('852666698', '100.00', 'bank_transfer', '2021-02-11 13:44:37', NULL, NULL)
ERROR - 2021-02-11 12:19:23 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('852666698', '100.00', 'bank_transfer', '2021-02-11 13:44:37', NULL, NULL, '201')
ERROR - 2021-02-11 12:19:30 --> Could not find the language line ""
ERROR - 2021-02-11 12:19:41 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('557233056', '100.00', 'bank_transfer', '2021-02-11 13:49:40', NULL, NULL, '201')
ERROR - 2021-02-11 12:21:59 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('557233056', '100.00', 'bank_transfer', '2021-02-11 13:49:40', NULL, NULL, '201')
ERROR - 2021-02-11 12:22:06 --> Could not find the language line ""
ERROR - 2021-02-11 12:22:15 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1182072626', '100.00', 'bank_transfer', '2021-02-11 13:52:15', NULL, NULL, '201')
ERROR - 2021-02-11 12:22:54 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1182072626', '100.00', 'bank_transfer', '2021-02-11 13:52:15', NULL, NULL, '201')
ERROR - 2021-02-11 12:23:00 --> Could not find the language line ""
ERROR - 2021-02-11 12:23:10 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1468617961', '100.00', 'bank_transfer', '2021-02-11 13:53:09', NULL, NULL, '201')
ERROR - 2021-02-11 12:30:40 --> Could not find the language line ""
ERROR - 2021-02-11 12:30:50 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:34:41 --> Query error: Unknown column 'va_number' in 'field list' - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:34:43 --> Query error: Unknown column 'va_number' in 'field list' - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:36:10 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:36:12 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:37:03 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 134
ERROR - 2021-02-11 12:37:09 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('970637882', '100.00', 'gopay', '2021-02-11 14:00:48', NULL, NULL, '201')
ERROR - 2021-02-11 12:37:18 --> Could not find the language line ""
ERROR - 2021-02-11 12:41:05 --> Could not find the language line ""
ERROR - 2021-02-11 12:41:15 --> Query error: Column 'order_id' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES (NULL, NULL, NULL, NULL, '-', '-', NULL)
ERROR - 2021-02-11 12:43:10 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 12:43:17 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 12:44:43 --> Query error: Column 'order_id' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES (NULL, NULL, NULL, NULL, '-', '-', NULL)
ERROR - 2021-02-11 12:45:31 --> Could not find the language line ""
ERROR - 2021-02-11 12:49:02 --> Could not find the language line ""
ERROR - 2021-02-11 13:10:37 --> Could not find the language line ""
ERROR - 2021-02-11 13:10:38 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 134
ERROR - 2021-02-11 13:10:42 --> Could not find the language line ""
ERROR - 2021-02-11 13:10:43 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 134
ERROR - 2021-02-11 13:10:49 --> Could not find the language line ""
ERROR - 2021-02-11 13:11:18 --> Could not find the language line ""
ERROR - 2021-02-11 13:12:55 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 146
ERROR - 2021-02-11 13:13:00 --> Query error: Duplicate entry '1365280736' for key 'PRIMARY' - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1365280736', '100.00', 'bank_transfer', '2021-02-11 14:41:27', '-', '-', '201')
ERROR - 2021-02-11 13:13:10 --> Could not find the language line ""
ERROR - 2021-02-11 13:15:16 --> Could not find the language line ""
ERROR - 2021-02-11 13:15:18 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 134
ERROR - 2021-02-11 13:15:24 --> Could not find the language line ""
ERROR - 2021-02-11 13:18:39 --> Could not find the language line ""
ERROR - 2021-02-11 13:19:30 --> Could not find the language line ""
ERROR - 2021-02-11 13:19:43 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('987367045', '100.00', 'gopay', '2021-02-11 14:49:41', NULL, NULL, '201')
ERROR - 2021-02-11 13:22:05 --> Could not find the language line ""
ERROR - 2021-02-11 13:22:07 --> Severity: error --> Exception: syntax error, unexpected ''va_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 151
ERROR - 2021-02-11 13:22:09 --> Could not find the language line ""
ERROR - 2021-02-11 13:22:12 --> Severity: error --> Exception: syntax error, unexpected ''va_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 151
ERROR - 2021-02-11 13:22:30 --> Could not find the language line ""
ERROR - 2021-02-11 13:22:32 --> Severity: error --> Exception: syntax error, unexpected ''va_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 151
ERROR - 2021-02-11 13:22:40 --> Could not find the language line ""
ERROR - 2021-02-11 13:23:16 --> Could not find the language line ""
ERROR - 2021-02-11 13:23:18 --> Severity: error --> Exception: syntax error, unexpected ''bank'' (T_CONSTANT_ENCAPSED_STRING), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 135
ERROR - 2021-02-11 13:23:25 --> Could not find the language line ""
ERROR - 2021-02-11 13:23:26 --> Severity: error --> Exception: syntax error, unexpected ''va_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 151
ERROR - 2021-02-11 13:23:29 --> Could not find the language line ""
ERROR - 2021-02-11 13:23:30 --> Severity: error --> Exception: syntax error, unexpected ''va_number'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 151
ERROR - 2021-02-11 13:23:40 --> Could not find the language line ""
ERROR - 2021-02-11 13:29:06 --> Could not find the language line ""
ERROR - 2021-02-11 13:29:19 --> Query error: Column 'va_number' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('985622051', '100.00', 'bank_transfer', '2021-02-11 14:59:18', '-', NULL, '201')
ERROR - 2021-02-11 13:36:30 --> Could not find the language line ""
ERROR - 2021-02-11 13:36:40 --> Query error: Column 'status_code' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1390485222', '100.00', 'bank_transfer', '2021-02-11 15:06:39', '-', '-', NULL)
ERROR - 2021-02-11 13:37:46 --> Query error: Duplicate entry '1390485222' for key 'PRIMARY' - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1390485222', '100.00', 'bank_transfer', '2021-02-11 15:06:39', 'bca', '16017146331', '201')
ERROR - 2021-02-11 13:37:52 --> Could not find the language line ""
ERROR - 2021-02-11 13:37:56 --> Could not find the language line ""
ERROR - 2021-02-11 13:38:36 --> Could not find the language line ""
ERROR - 2021-02-11 13:38:46 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1133077541', '100.00', 'gopay', '2021-02-11 15:08:44', NULL, NULL, '201')
ERROR - 2021-02-11 13:39:14 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1133077541', '100.00', 'gopay', '2021-02-11 15:08:44', NULL, NULL, '201')
ERROR - 2021-02-11 13:50:56 --> Could not find the language line ""
ERROR - 2021-02-11 13:51:04 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', NULL, NULL, '201')
ERROR - 2021-02-11 13:51:22 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', NULL, NULL, '201')
ERROR - 2021-02-11 13:51:23 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', NULL, NULL, '201')
ERROR - 2021-02-11 13:51:45 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', NULL, NULL, '201')
ERROR - 2021-02-11 13:52:41 --> Query error: Column 'va_number' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', '-', NULL, '201')
ERROR - 2021-02-11 13:52:57 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('287148798', '100.00', 'bank_transfer', '2021-02-11 15:21:04', NULL, NULL, '201')
ERROR - 2021-02-11 13:53:36 --> Could not find the language line ""
ERROR - 2021-02-11 13:53:47 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1368219703', '100.00', 'bank_transfer', '2021-02-11 15:23:47', NULL, NULL, '201')
ERROR - 2021-02-11 14:03:56 --> Could not find the language line ""
ERROR - 2021-02-11 14:04:06 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:04:58 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:05:02 --> Could not find the language line ""
ERROR - 2021-02-11 14:05:14 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:05:45 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:05:46 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:05:59 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:06:00 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:06:48 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:18:44 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:18:45 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:20:06 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:20:06 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 155
ERROR - 2021-02-11 14:21:41 --> Could not find the language line ""
ERROR - 2021-02-11 14:24:12 --> Could not find the language line ""
ERROR - 2021-02-11 14:24:20 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('23556879', '100.00', 'bank_transfer', '2021-02-11 15:54:20', NULL, NULL, '201')
ERROR - 2021-02-11 14:24:54 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('23556879', '100.00', 'bank_transfer', '2021-02-11 15:54:20', NULL, NULL, '201')
ERROR - 2021-02-11 14:24:56 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('23556879', '100.00', 'bank_transfer', '2021-02-11 15:54:20', NULL, NULL, '201')
ERROR - 2021-02-11 14:24:57 --> Query error: Column 'bank' cannot be null - Invalid query: INSERT INTO `transaksi_midtrans` (`order_id`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('23556879', '100.00', 'bank_transfer', '2021-02-11 15:54:20', NULL, NULL, '201')
ERROR - 2021-02-11 14:36:36 --> Could not find the language line ""
ERROR - 2021-02-11 14:37:20 --> Could not find the language line ""
ERROR - 2021-02-11 14:38:20 --> Could not find the language line ""
ERROR - 2021-02-11 14:38:42 --> Could not find the language line ""
ERROR - 2021-02-11 15:54:47 --> Could not find the language line ""
ERROR - 2021-02-11 15:54:51 --> Could not find the language line ""
ERROR - 2021-02-11 15:54:52 --> Severity: error --> Exception: CURL Error: Could not resolve host: app.sandbox.midtrans.com C:\xampp\htdocs\cimidtrans\application\libraries\Midtrans.php 129
ERROR - 2021-02-11 15:55:08 --> Could not find the language line ""
ERROR - 2021-02-11 15:55:33 --> Could not find the language line ""
ERROR - 2021-02-11 16:15:18 --> Could not find the language line ""
ERROR - 2021-02-11 16:15:37 --> Could not find the language line ""
ERROR - 2021-02-11 16:30:20 --> Could not find the language line ""
ERROR - 2021-02-11 16:31:14 --> Could not find the language line ""
ERROR - 2021-02-11 16:35:59 --> Could not find the language line ""
ERROR - 2021-02-11 16:36:34 --> Could not find the language line ""
ERROR - 2021-02-11 17:01:43 --> Could not find the language line ""
ERROR - 2021-02-11 17:01:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 86
ERROR - 2021-02-11 17:01:46 --> Could not find the language line ""
ERROR - 2021-02-11 17:01:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 86
ERROR - 2021-02-11 17:03:33 --> Could not find the language line ""
ERROR - 2021-02-11 17:03:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:03:35 --> Could not find the language line ""
ERROR - 2021-02-11 17:03:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:03:36 --> Could not find the language line ""
ERROR - 2021-02-11 17:03:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:03:40 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:03:46 --> Could not find the language line ""
ERROR - 2021-02-11 17:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:03:47 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:03:53 --> Could not find the language line ""
ERROR - 2021-02-11 17:03:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:03:56 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:04:31 --> Could not find the language line ""
ERROR - 2021-02-11 17:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:05:35 --> Could not find the language line ""
ERROR - 2021-02-11 17:05:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:05:37 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:05:56 --> Could not find the language line ""
ERROR - 2021-02-11 17:05:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:05:58 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:06:02 --> Could not find the language line ""
ERROR - 2021-02-11 17:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:06:04 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:06:21 --> Could not find the language line ""
ERROR - 2021-02-11 17:06:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:06:23 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:06:26 --> Could not find the language line ""
ERROR - 2021-02-11 17:06:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:06:34 --> Could not find the language line ""
ERROR - 2021-02-11 17:06:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:06:40 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:06:54 --> Could not find the language line ""
ERROR - 2021-02-11 17:06:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:07:26 --> Could not find the language line ""
ERROR - 2021-02-11 17:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:07:29 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 43
ERROR - 2021-02-11 17:07:33 --> Could not find the language line ""
ERROR - 2021-02-11 17:07:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:08:46 --> Could not find the language line ""
ERROR - 2021-02-11 17:08:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:08:56 --> Could not find the language line ""
ERROR - 2021-02-11 17:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:09:16 --> Could not find the language line ""
ERROR - 2021-02-11 17:09:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:09:34 --> Could not find the language line ""
ERROR - 2021-02-11 17:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:10:52 --> Could not find the language line ""
ERROR - 2021-02-11 17:10:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:11:06 --> Could not find the language line ""
ERROR - 2021-02-11 17:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:11:08 --> Could not find the language line ""
ERROR - 2021-02-11 17:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:12:12 --> Could not find the language line ""
ERROR - 2021-02-11 17:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:13:36 --> Could not find the language line ""
ERROR - 2021-02-11 17:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_detail.php 85
ERROR - 2021-02-11 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 89
ERROR - 2021-02-11 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 89
ERROR - 2021-02-11 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 89
ERROR - 2021-02-11 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 89
ERROR - 2021-02-11 17:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 89
ERROR - 2021-02-11 17:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:30:23 --> Severity: Compile Error --> Cannot redeclare User::switch_group() C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 17:30:27 --> Severity: Compile Error --> Cannot redeclare User::switch_group() C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 17:30:27 --> Severity: Compile Error --> Cannot redeclare User::switch_group() C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 17:30:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:30:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:31:02 --> Could not find the language line ""
ERROR - 2021-02-11 17:31:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group.php 111
ERROR - 2021-02-11 17:32:11 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-11 17:32:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\models\User_model.php 421
ERROR - 2021-02-11 17:41:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\models\Quiz_model.php 878
ERROR - 2021-02-11 17:41:49 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\cimidtrans\system\libraries\Email.php 1896
ERROR - 2021-02-11 17:41:49 --> Could not find the language line "hello"
ERROR - 2021-02-11 17:41:49 --> Could not find the language line "user_id"
ERROR - 2021-02-11 17:41:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\cimidtrans\application\views\view_result.php 356
ERROR - 2021-02-11 17:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\models\Quiz_model.php 878
ERROR - 2021-02-11 17:42:09 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\cimidtrans\system\libraries\Email.php 1896
ERROR - 2021-02-11 17:42:09 --> Could not find the language line "hello"
ERROR - 2021-02-11 17:42:09 --> Could not find the language line "user_id"
ERROR - 2021-02-11 17:42:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\cimidtrans\application\views\view_result.php 356
ERROR - 2021-02-11 17:51:49 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\cimidtrans\application\controllers\User.php 450
ERROR - 2021-02-11 17:53:26 --> Severity: Error --> Class '' not found C:\xampp\htdocs\cimidtrans\system\database\drivers\mysqli\mysqli_result.php 229
ERROR - 2021-02-11 17:53:26 --> Severity: Error --> Class '' not found C:\xampp\htdocs\cimidtrans\system\database\drivers\mysqli\mysqli_result.php 229
ERROR - 2021-02-11 17:53:30 --> Severity: Error --> Class '' not found C:\xampp\htdocs\cimidtrans\system\database\drivers\mysqli\mysqli_result.php 229
ERROR - 2021-02-11 17:54:32 --> Severity: Error --> Class '' not found C:\xampp\htdocs\cimidtrans\system\database\drivers\mysqli\mysqli_result.php 229
ERROR - 2021-02-11 17:54:32 --> Severity: Error --> Class '' not found C:\xampp\htdocs\cimidtrans\system\database\drivers\mysqli\mysqli_result.php 229
ERROR - 2021-02-11 18:06:21 --> Severity: error --> Exception: Too few arguments to function User::change_group_history(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 18:06:32 --> Could not find the language line ""
ERROR - 2021-02-11 18:06:37 --> Severity: error --> Exception: Too few arguments to function User::change_group_history(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 18:18:37 --> Could not find the language line ""
ERROR - 2021-02-11 18:45:48 --> Severity: error --> Exception: Too few arguments to function User::change_group_history(), 0 passed in C:\xampp\htdocs\cimidtrans\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\cimidtrans\application\controllers\User.php 374
ERROR - 2021-02-11 18:51:50 --> Could not find the language line ""
ERROR - 2021-02-11 18:51:52 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 158
ERROR - 2021-02-11 18:51:55 --> Could not find the language line ""
ERROR - 2021-02-11 18:51:57 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 158
ERROR - 2021-02-11 18:52:01 --> Could not find the language line ""
ERROR - 2021-02-11 18:52:03 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 158
ERROR - 2021-02-11 18:52:48 --> Could not find the language line ""
ERROR - 2021-02-11 18:53:27 --> Could not find the language line ""
ERROR - 2021-02-11 18:54:25 --> Could not find the language line ""
ERROR - 2021-02-11 18:54:27 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 159
ERROR - 2021-02-11 18:54:37 --> Could not find the language line ""
ERROR - 2021-02-11 18:54:38 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 159
ERROR - 2021-02-11 18:54:49 --> Could not find the language line ""
ERROR - 2021-02-11 18:54:50 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 159
ERROR - 2021-02-11 18:55:25 --> Could not find the language line ""
ERROR - 2021-02-11 18:55:27 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\cimidtrans\application\controllers\snap.php 159
ERROR - 2021-02-11 18:55:30 --> Could not find the language line ""
ERROR - 2021-02-11 18:55:33 --> Could not find the language line ""
ERROR - 2021-02-11 19:06:19 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 29
ERROR - 2021-02-11 19:06:29 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 29
ERROR - 2021-02-11 19:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\result_list.php 179
ERROR - 2021-02-11 19:57:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\result_list.php 181
