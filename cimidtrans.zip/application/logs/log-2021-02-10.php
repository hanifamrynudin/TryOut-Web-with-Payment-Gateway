<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-10 05:54:05 --> Severity: error --> Exception: CURL Error: Could not resolve host: app.sandbox.midtrans.com C:\xampp\htdocs\cimidtrans\application\libraries\Midtrans.php 129
ERROR - 2021-02-10 09:41:29 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
