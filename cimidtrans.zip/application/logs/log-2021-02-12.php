<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-12 03:37:39 --> Could not find the language line ""
ERROR - 2021-02-12 03:45:52 --> Could not find the language line ""
ERROR - 2021-02-12 03:45:55 --> Severity: error --> Exception: CURL Error: Could not resolve host: app.sandbox.midtrans.com C:\xampp\htdocs\cimidtrans\application\libraries\Midtrans.php 129
ERROR - 2021-02-12 03:46:12 --> Could not find the language line ""
ERROR - 2021-02-12 03:46:23 --> Could not find the language line ""
ERROR - 2021-02-12 03:46:37 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `trans_midtrans` (`order_id`, `email`, `kelas`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('474885896', NULL, '2 Diamond', '10000.00', 'bank_transfer', '2021-02-12 05:16:37', 'bca', '16017506470', '201')
ERROR - 2021-02-12 03:47:16 --> Could not find the language line ""
ERROR - 2021-02-12 03:47:18 --> Could not find the language line ""
ERROR - 2021-02-12 03:47:27 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `trans_midtrans` (`order_id`, `email`, `kelas`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('1759202081', NULL, '2 Diamond', '10000.00', 'bank_transfer', '2021-02-12 05:17:27', 'bca', '16017096191', '201')
ERROR - 2021-02-12 03:48:04 --> Could not find the language line ""
ERROR - 2021-02-12 03:48:13 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `trans_midtrans` (`order_id`, `email`, `kelas`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('104201387', NULL, '2 Diamond', '10000.00', 'bank_transfer', '2021-02-12 05:18:13', 'bca', '16017214358', '201')
ERROR - 2021-02-12 03:50:07 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `trans_midtrans` (`order_id`, `email`, `kelas`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('104201387', NULL, NULL, '10000.00', 'bank_transfer', '2021-02-12 05:18:13', 'bca', '16017214358', '201')
ERROR - 2021-02-12 03:51:51 --> Query error: Column 'kelas' cannot be null - Invalid query: INSERT INTO `trans_midtrans` (`order_id`, `email`, `kelas`, `gross_amount`, `payment_type`, `transaction_time`, `bank`, `va_number`, `status_code`) VALUES ('104201387', 'user@example.com', NULL, '10000.00', 'bank_transfer', '2021-02-12 05:18:13', 'bca', '16017214358', '201')
ERROR - 2021-02-12 03:52:01 --> Could not find the language line ""
ERROR - 2021-02-12 04:00:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-12 04:06:00 --> Could not find the language line ""
ERROR - 2021-02-12 04:06:25 --> Could not find the language line ""
ERROR - 2021-02-12 04:06:28 --> Could not find the language line ""
ERROR - 2021-02-12 04:07:06 --> Could not find the language line ""
ERROR - 2021-02-12 04:07:13 --> Could not find the language line ""
ERROR - 2021-02-12 04:09:49 --> Could not find the language line "uid"
ERROR - 2021-02-12 04:10:53 --> Could not find the language line ""
ERROR - 2021-02-12 04:10:53 --> Could not find the language line "uid"
ERROR - 2021-02-12 04:15:31 --> Could not find the language line ""
ERROR - 2021-02-12 04:15:31 --> Could not find the language line "uid"
ERROR - 2021-02-12 04:25:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-12 04:27:07 --> Could not find the language line ""
ERROR - 2021-02-12 04:39:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 16
ERROR - 2021-02-12 04:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 16
ERROR - 2021-02-12 04:48:22 --> Query error: Table 'savsoft.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:48:23 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 04:49:19 --> Query error: Table 'savsoft.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:49:19 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 04:49:26 --> Query error: Table 'savsoft.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:49:26 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 04:49:37 --> Query error: Table 'savsoft.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:49:37 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 04:49:37 --> Query error: Table 'savsoft.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:49:37 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 04:49:42 --> Query error: Table 'savsoft.email' doesn't exist - Invalid query: SELECT *
FROM `email`
WHERE `email` IS NULL
ERROR - 2021-02-12 04:49:42 --> Severity: error --> Exception: Call to a member function row_array() on bool C:\xampp\htdocs\cimidtrans\application\controllers\User.php 406
ERROR - 2021-02-12 05:08:04 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:08:14 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:08:14 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 3
ERROR - 2021-02-12 05:08:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:08:15 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:08:15 --> Severity: Warning --> mysqli_fetch_array() expects parameter 1 to be mysqli_result, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 3
ERROR - 2021-02-12 05:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:08:52 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:08:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:08:53 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:08:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:09:02 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:09:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:09:16 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cimidtrans\application\views\dashboard.php 237
ERROR - 2021-02-12 05:09:34 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 2
ERROR - 2021-02-12 05:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 20
ERROR - 2021-02-12 05:10:34 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:10:35 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:10:35 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:11:57 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:11:58 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:12:52 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:12:52 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 3
ERROR - 2021-02-12 05:13:35 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:13:35 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 46
ERROR - 2021-02-12 05:13:36 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:13:36 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 46
ERROR - 2021-02-12 05:13:41 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:13:41 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 46
ERROR - 2021-02-12 05:13:42 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:13:42 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 46
ERROR - 2021-02-12 05:13:42 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:13:42 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 46
ERROR - 2021-02-12 05:13:55 --> Severity: Warning --> mysqli_query() expects parameter 1 to be mysqli, null given C:\xampp\htdocs\cimidtrans\application\controllers\User.php 405
ERROR - 2021-02-12 05:19:44 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 416
ERROR - 2021-02-12 05:21:11 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 437
ERROR - 2021-02-12 05:21:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 437
ERROR - 2021-02-12 05:21:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 437
ERROR - 2021-02-12 05:21:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 437
ERROR - 2021-02-12 05:34:42 --> Severity: error --> Exception: syntax error, unexpected 'if' (T_IF), expecting ')' C:\xampp\htdocs\cimidtrans\application\controllers\User.php 410
ERROR - 2021-02-12 05:35:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 17
ERROR - 2021-02-12 05:35:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cimidtrans\application\views\change_group_history.php 17
