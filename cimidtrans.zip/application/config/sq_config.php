<?php 
		$sq_base_url='';
		$sq_hostname='';
		$sq_dbname='savsoft';
		$sq_dbusername='root';
		$sq_dbpassword='';
		?>